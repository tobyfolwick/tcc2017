// declare a module
      var myApp = angular.module('myApp', []);